# Changelog

本文件记录 dianleida-skill 的所有版本变更。格式遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/) 原则，版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/) 规范。

---

## [1.1.0] — 2026-11-03

### Added
- 新增 6 个业务工具文档补全：`product_trend_new_list`（趋势新品榜）、`monitor_offer_list`（监控商品列表）、`monitor_shop_list`（监控店铺列表）、`monitor_offer_add`（添加监控商品）、`monitor_shop_add`（添加监控店铺）、`monitor_shop_analysis`（店铺深度分析）
- `references/工具出参入参.md` 新增 §11-§16：6 个新工具的入参总表、出参字段表与实测响应说明
- `references/接口与参数参考.md` 工具总览新增 6 行，并新增对应调用策略章节（调用约束、使用场景、展示规则）
- 展示规范速查表新增 4 行：趋势新品榜、监控商品列表、监控店铺列表、店铺深度分析
- `SKILL.md` 工具清单表新增 6 个工具（含此前已在其他章节提及但未列入工具表的 global_image_search / ali_offer_realtime_detail / ali_offer_sku_prices）
- `SKILL.md` 场景识别路由树新增 6 条分支：趋势新品、监控商品列表、监控店铺列表、添加监控商品、添加监控店铺、店铺深度分析
- `SKILL.md` 详情类工具全字段披露规则新增 `monitor_shop_analysis`
- `point-protection.md` 计费口径业务工具数 10 → 16，补入 6 个新工具
- `manifest.yaml` 与 `SKILL.md` frontmatter 版本号 1.0.5 → 1.1.0，描述同步扩充新能力

### Changed
- `references/工具出参入参.md` 头部说明更新：工具总数 7 → 16，核对日期更新为 2026-11-03
- 监控类工具与趋势新品榜参数均为**直接传参（不包 req 对象）**，与商品搜索/榜单等工具的 req 包装方式不同，文档中已明确标注

---

## [1.0.5] — 2026-10-12

### Added
- 新增接口收录：`cross_border_product_search_list`（跨境货源搜索）与 `shop_rank_list`（店铺榜单）——工具清单、场景识别分支、默认参数映射、参考文档参数表/响应字段表/调用硬约束/实测调用示例
- `SKILL.md` frontmatter 补齐提审必填字段：version、display_name、display_name_en、description_zh、description_en（2026-10-19）
- 新增 3 个业务工具文档（2026-10-22）：`global_image_search`（全网图搜，TikTok/Amazon/1688 跨平台找同款）、`ali_offer_realtime_detail`（商品属性与资质证书）、`ali_offer_sku_prices`（全部 SKU 价格与库存）——`references/工具出参入参.md` 新增 §8-§10（入参表、出参说明与展示规则），`references/接口与参数参考.md` 工具总览新增 3 行并新增 3 个调用小节，`SKILL.md` 场景识别新增 3 条路由分支
- 三个详情类工具新增「全字段披露」强制展示规则：只要调用 `global_image_search`/`ali_offer_realtime_detail`/`ali_offer_sku_prices`，接口返回的全部字段内容必须完整展示给用户，不得省略、概括或只挑部分字段（SKILL.md 场景识别强调块 + 接口与参数参考各小节 + 展示规范速查表新增 3 行）
- `point-protection.md` 计费口径业务工具数 7 → 10，补入 3 个新工具
- `SKILL.md` 新增 AI 搜索模式（searchType=4）场景分支与弱关键词兜底路由
- `references/接口与参数参考.md` 新增 AI 搜索模式小节（意图分析、trend 字段说明并注明其非 AI 搜索独有、默认排序）与 searchType 参数行
- 默认参数映射表新增 6 行：飙升/上新/复购（仅榜单）、跨境货源、找店铺、弱关键词；意图推断映射表新增安心购（shopService）、先采后付（proxyRights）行
- 商品榜单新增排序字段说明：bookedGrowthRate（飙升）、offerCreateTime（上新）、offerRepurchaseRate（复购率）与榜单排序意图映射
- `SKILL.md` 新增「店铺榜单展示」模板：中文指标表格 9 列口径，标题注明榜单口径
- `SKILL.md` 新增「趋势字段（trend）」展示规则：默认渲染纯趋势曲线，不标注具体数值；「价格档位字段」规则：阶梯价/代发价默认不展示、问及才展示
- `references/接口与参数参考.md` 展示规范速查表新增店铺榜单、trend 趋势两行
- `SKILL.md` 移除 get_user_info 禁调标注（连接器已下线并移除该工具壳）
- 新增 `references/工具出参入参.md`：7 个业务工具各自的完整入参总表、出参字段表与实测精简响应示例（连接器 schema + 店雷达官方文档 + 线上实测三方核对，2026-10-16），含通用信封结构与 `trend`/`quantityPrices`/`buyerProtections` 等需二次解析字段说明；`SKILL.md` 深度参考增加该文档链接指引（仅指针，内容不并入 SKILL.md）

### Changed
- 图片搜同款路由调整（2026-10-22，重点规则）：用户以图搜货/找同款时**默认调用 `global_image_search`（全网图搜，未指明平台时 platform=1688）**，仅当用户明确要求「只用 1688 图搜/批量寻源/多图逐张搜」时才改用 `image_search`；SKILL.md 场景识别路由与图片搜同款工作流、接口与参数参考（工具总览、图片寻源与全网图搜小节）、工具出参入参（§6/§8）同步更新
- 数量规则适用范围扩展至跨境搜索与店铺榜单（分页上限 100）；多标识拼接队列明确仅作用于 product_search_list，跨境货源词组直接路由跨境接口
- image_search 统一为「仅 1 张」：用户提供多张时依次逐张提交，不再让用户选择
- `point-protection.md` 业务工具数 5 → 7，并同步补充新接口计费说明
- `references/接口与参数参考.md` 与 `references/工具出参入参.md` 分工重构（字段字典与调用策略解耦）：接口与参数参考删除与字段字典重复的商品搜索基础参数表、跨境参数两表、店铺榜单请求/响应字段表，改为指向工具出参入参对应章节，保留工具总览、意图推断映射、调用硬约束、榜单日期规则/排序意图与 3 个店铺榜单实测请求示例（283 → 183 行）
- `references/工具出参入参.md` 按连接器 schema 与官方文档核对补正：商品搜索入参补 `productIds`（补齐 38 个）、出参补 `ordersCount`/`salesCount`，商品榜单入参补 `productIds`/`goodsUrl`；注明 `beginOrdersCount/endOrdersCount/beginSalesCount/endSalesCount` 官方文档收录但连接器 schema 未暴露、不可经连接器传参
- `SKILL.md` 调用前置规则升级：`references/工具出参入参.md` 由按需查阅改为**会话内首次业务调用前必读**——深度参考措辞改为强制规则，并在握手流程第 2 步挂入「先读目标工具对应章节、再发起调用」，避免凭猜测拼参数、找错字段（如 orderCount/ordersCount、saleQuantity/salesCount 混淆）
- `manifest.yaml` 版本号 1.0.4 → 1.0.5；`version.json` 同步更新至 1.0.5

---

## [1.0.4] — 2026-09-24

### Added
- `SKILL.md` 新增「多商品标识查询与拼接（强制）」：用户指令含多个商品标识时，按 跨境Select→新品→1688严选→镇店之宝→支持定制 的优先级排队，标识类调用每轮最多 2 次，每次结果保存；不足 100 条时调下一个标识按 offerId 去重拼接补足；两次标识调用后仍不足（含均返回 0）时，第 3 次去掉商品标识按关键词模糊搜索兜底拼接；交付时披露拼接构成与销量口径
- `SKILL.md` 注意事项新增第 9 条「多标识拼接」入口

### Changed
- `manifest.yaml` 版本号 1.0.3 → 1.0.4

---

## [1.0.3] — 2026-09-04

### Added
- 新增运行时版本检测与自动拉取更新机制
- 新增 `version.json` — 线上版本清单文件，包含版本号、文件下载 URL 列表
- 新增 `references/更新策略.md` — 完整的运行时检测、拉取、回滚机制文档
- 新增 `CHANGELOG.md` — 版本变更记录文件
- `SKILL.md` 新增「版本检测与自动更新」章节，定义技能加载时的检测流程、更新提示、拉取步骤和回滚逻辑
- `manifest.yaml` 新增 `update_strategy` 块，包含 `version_check_url`、`check_on_load`、`check_timeout`、`auto_backup` 等配置

### Changed
- `manifest.yaml` 版本号确定为 1.0.3
- 优化未配置 MCP 时的处理策略：可主动询问用户是否提供店雷达 MCP 密钥，并尝试自动配置为 `dld-mcp`
- 自动配置失败时，改为根据当前 AI 工具提供前端手动配置流程

---

## [1.0.3] — 2026-08-24

### Added
- 初始版本发布
- 店雷达 1688 选品引导技能核心功能
- 支持 4 个 MCP 工具：`product_search_list`、`product_billboard_list`、`product_info`、`get_category_info`
- MCP 连接器智能识别（基于服务名称匹配，不校验工具名）
- 首次握手强制流程（识别 → 调用 → 错误分支处理）
- 意图识别引擎（商品意图 / 服务意图 / 混合意图）
- 默认参数自动推断映射表（15 种用户表达 → 参数推断）
- 默认 HTML 商品页面输出 + 聊天内嵌卡片可选模式
- 意图驱动链接选择策略（商品链接 / 店铺链接 / 混合）
- 完整的 `references/接口与参数参考.md` 深度参考文档
